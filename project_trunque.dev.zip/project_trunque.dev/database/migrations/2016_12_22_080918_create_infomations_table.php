<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInfomationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('infomations', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('companyname');
  			$table->string('tradingname');
  			$table->string('companyaddress');
  			$table->string('campaddress');
  			$table->string('companyphonenumber');
  			$table->string('campphonenumber');
			$table->string('businesslicense');
			$table->string('taxcode');
			$table->string('account');
			$table->string('email');
			$table->string('images');
 			$table->integer('admin_id')->unsigned();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('infomations');
	}

}
